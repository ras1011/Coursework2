[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=19503159)
# CSC-20004 - Coursework

This is the starting code for the coursework of module CSC-20004 Advanced Programming practices.

Please refer to the text of the coursework, available on KLE, for an explanation of the code and the instructions for submission. Make sure to check for the deadline on KLE.

The hierarchy of the provided classes is shown below.

Hierarchy of arena-related classes:

![UML diagram 1](./hierarchy1.png)

Hierarchy of Robots:

![UML diagram 2](./hierarchy2.png)
